<?php 
	include "resources/initiate.php";
	$title = "Bartap - Welcome";
	$style = "styles/welcome.css";
	include "components/header.php";
?>

<div id="welcome">
	<h1>Welcome to Bartap!</h1>
	<img src="images/logo.png" alt="Bartap">
	<p>Welcome to Bartap; your one stop shop for the best. Jump right into our selection using the navigation, or click on your account to change your details.</p>
</div>

<?php
	include "components/footer.php";
?>