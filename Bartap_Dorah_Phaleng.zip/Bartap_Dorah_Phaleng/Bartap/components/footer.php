		<footer>
			<nav id="bottom-nav">
				<ul>
					<li class="text-link"><a href="admin/gateway.php">ADMIN</a></li>
					
				</ul>
			</nav>
		</footer>
		</div>
	</body>
</html>