<ul>
	<li><a href="account.php">MY ACCOUNT</a></li>
	<li><a href="resources/logout.php">LOG OUT</a></li>
</ul>
