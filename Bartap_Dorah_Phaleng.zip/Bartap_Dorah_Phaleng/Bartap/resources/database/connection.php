<?php 

	
    //XAMPP server
	$db = new mysqli('localhost', 'root', '','simdb');
	
	
	
	
	if($db->connect_errno) {
		die('Unable to connect to database');
	}


?>