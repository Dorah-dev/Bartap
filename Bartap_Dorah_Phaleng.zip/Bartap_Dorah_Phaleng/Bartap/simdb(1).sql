-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `simdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `adminuser` varchar(32) NOT NULL,
  `adminpass` varchar(32) NOT NULL,
`adminid` int(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminuser`, `adminpass`, `adminid`) VALUES
('customer', '5f4d', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
`id` int(6) NOT NULL,
  `name` varchar(45) NOT NULL,
  `drink` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `cl` float NOT NULL,
  `abv` float NOT NULL,
  `price` float NOT NULL,
  `image` varchar(40) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `drink`, `type`, `cl`, `abv`, `price`, `description`, `image`, `created`) VALUES
(1, 'Lager;s Old No. 7 Half Bottle', 'Whiskey', 'Tennessee Whiskey', 35, 40, 12.95,'bourbon/lager.jpg', '2021-11-08 16:43:42'),
(2, 'IPA', 'Whiskey', 'Bourbon', 70, 40, 16.95, 'bourbon/ipa.jpg', '2021-11-08 16:43:42'),
(3, 'Weisbier', 'Whiskey', 'Bourbon', 70, 40, 19.75, 'bourbon/weissbier.jpg', '2021-11-08 16:43:42'),

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(5) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `gender`, `email`, `password`) VALUES
(7, 'Dorah', 'Phaleng', 'Female', 'dorahphaleng@hotmail.com', '363b122c528f54df4a0446b6bab05515'),
(8, 'Gladwin', 'Brown', 'Female', 'gladwin@live.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(13, 'riaan', 'green', 'Male', 'riaangreen@hotmail.co.za', '5f4dcc3b5aa765d61d8327deb882cf99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`adminid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `adminid` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `id` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
